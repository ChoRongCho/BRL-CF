# Development and Validation of the System Trustworthiness Scale

## 서지정보

| 항목 | 내용 |
| --- | --- |
| 저자 | Gene M. Alarcon, August Capiola, Michael A. Lee, Sasha Willis, Izz Aldin Hamdan, Sarah A. Jessup, Krista N. Harris |
| 출판사 / 학술지 | SAGE / Human Factors |
| 학회 | Human Factors and Ergonomics Society |
| 연도 / 권·호 / 페이지 | 2024 / 66(7) / 1893–1913 |
| 온라인 최초 출판 | 2023-07-17 |
| DOI | [10.1177/00187208231189000](https://doi.org/10.1177/00187208231189000) |
| 인용수 | [OpenAlex](https://openalex.org/W4384559207) 표시값 15회; [ResearchGate](https://www.researchgate.net/publication/372418058_Development_and_Validation_of_the_System_Trustworthiness_Scale) 표시값 20회 |
| 인용수 조회일 | 2026-09-13. 웹 검색에서 조회된 표시값으로 집계·갱신 시점이 다르며, Google Scholar나 실시간 총인용수와 같지 않음 |
| 검토 원문 | [SAGE 웹 본문](https://journals.sagepub.com/doi/10.1177/00187208231189000), [출판사 PDF의 웹 추출 본문](https://journals.sagepub.com/doi/pdf/10.1177/00187208231189000) |

기존 `.txt`는 빈 제목 메모다. 이번에는 웹에서 논문 본문과 최종 문항 표를 확인했으며, 로컬 PDF를 다운로드했다는 뜻은 아니다. PDF 첫 페이지의 Author(s) Note는 논문 내용을 미국 연방정부 저작물로서 public domain이라고 명시한다.

**인용:** Alarcon, G. M., Capiola, A., Lee, M. A., Willis, S., Hamdan, I. A., Jessup, S. A., & Harris, K. N. (2024). Development and validation of the system trustworthiness scale. *Human Factors, 66*(7), 1893–1913. https://doi.org/10.1177/00187208231189000

## 1. 이 설문은 무엇을 보려는가

STS는 **“내가 이 시스템을 믿는가”라는 신뢰 태도와, “이 시스템이 어떤 점에서 믿을 만한가”라는 trustworthiness 평가를 구분**한다. 저자는 성능·용도·작동 과정에 대한 지각이 신뢰의 선행요인이며, 신뢰가 의존 행동으로 이어진다는 이론에 근거한다.

| 하위척도 | 핵심 질문 | 문항 수 |
| --- | --- | --- |
| Performance | 시스템이 정확하고 유능하게 일을 수행하는가? | 5 |
| Purpose | 시스템이 이 작업·맥락을 위해 만들어졌으며 의도된 용도로 쓰이고 있는가? | 5 |
| Process | 시스템의 작동·판단 방식이 전달되고 이해 가능한가? | 5 |

**최종 15문항·3요인**이다. TOAST가 Understanding과 Performance를 분리했다면, STS는 특히 **Purpose와 Process를 독립적으로 평가**하려 한다. 이것이 자동으로 TOAST보다 우수하다는 뜻은 아니며, 무엇을 측정할지에 따라 적합성이 달라진다. 근거: [원문 Introduction 및 General Discussion](https://journals.sagepub.com/doi/10.1177/00187208231189000).

## 2. 최종 설문 15문항 — 영어 원문과 문항별 의미

**출처: Table 4, 논문 p. 1906 / PDF 14쪽.** 최종 척도를 Study 2의 통계 예측 모델에 적용한 문구다. 따라서 “statistical model”을 임의로 “system”으로 바꾸지 않고 그대로 옮겼다. 아래 설명은 문구와 요인 배정에 근거한 **리뷰 해석**이다.

**응답:** 5-point Likert — **1 = Strongly Disagree**, **5 = Strongly Agree**. R은 역채점 표시다.

### Performance — 실제 수행에 대한 평가

| 번호 | English item — verbatim | 보고자 하는 측면 |
| --- | --- | --- |
| 1 | The statistical model is effective. | 원하는 효과·성과를 내는가 |
| 2 | The statistical model performs the task accurately. | 과제 수행 결과가 정확한가 |
| 3 | The statistical model is reliable. | 수행을 믿고 맡길 만큼 안정적인가 |
| 4 | The statistical model is incompetent. (R) | 과제를 수행할 능력이 부족하다고 느끼는가 — 역방향 |
| 5 | The statistical model performs its job well. | 전반적으로 맡은 일을 잘하는가 |

다섯 문항 모두 사용자가 지각한 수행 역량을 묻는다. 실제 정확도 수치와 같지는 않다. TOAST Performance에 있는 “내 목표에 도움이 된다”, “정보에 의존하는 것이 편하다”, “예상 밖의 반응이 드물다”보다 수행 능력에 집중된 구성이다.

### Purpose — 설계 의도와 현재 용도의 적합성

| 번호 | English item — verbatim | 보고자 하는 측면 |
| --- | --- | --- |
| 6 | The statistical model is programmed specifically to complete this task. | 바로 이 작업을 위해 만들어진 시스템인가 |
| 7 | This statistical model executes its designer’s intent. | 실제 수행이 설계자의 의도에 부합하는가 |
| 8 | The statistical model is utilized as its creators intended. | 사용 방식이 제작자가 의도한 방식인가 |
| 9 | The statistical model is used as intended. | 의도된 용도대로 사용되고 있는가 |
| 10 | The statistical model is designed to assist users in this context. | 현재 맥락의 사용자를 돕도록 설계되었는가 |

**여기서 Purpose는 시스템이 내 의도를 잘 파악하는지 묻는 척도가 아니다.** 설계된 용도와 실제 적용 맥락의 일치를 묻는다. 또한 “설계 의도대로 작동한다”는 평가가 그 의도 자체의 도덕적 선함을 뜻하지는 않는다. 문항 8과 9는 표현과 내용이 상당히 비슷하다.

### Process — 설명·투명성·이해 가능성

| 번호 | English item — verbatim | 보고자 하는 측면 |
| --- | --- | --- |
| 11 | I understand how the statistical model is supposed to work. | 기대되는 작동 방식을 내가 이해하는가 |
| 12 | The statistical model conveys its reasoning to users. | 시스템이 판단 근거·추론을 사용자에게 전달하는가 |
| 13 | The statistical model’s operation/decision making is transparent. | 작동·의사결정 과정이 투명한가 |
| 14 | It is clear to me how the statistical model makes decisions. | 어떤 방식으로 결정하는지 내가 명확히 아는가 |
| 15 | It is clear how the statistical model completes its tasks. | 과제가 수행되는 과정이 명확한가 |

**Q12는 시스템의 설명 제공**, **Q11·Q14는 사용자가 느끼는 이해**, **Q13·Q15는 과정의 투명성과 명확성**에 초점이 있다. 같은 Process 요인이지만 완전히 같은 질문은 아니다. 모두 지각·자기보고이며 객관적인 이해도 시험을 대신하지 않는다.

## 3. 응답과 채점

- 1–5 응답에서 **Q4만 역채점**한다: `Q4_R = 6 − Q4`.
- 저자는 Practical Implications에서 **각 구성개념별 점수를 합산**하여 평가하는 사용법을 설명한다.
- 아래 평균은 해석하기 쉽게 1–5 범위로 나타낸 것으로, 각 5문항 합계를 5로 나눈 **리뷰용 계산 표현**이다.

```text
Performance 합계 = Q1 + Q2 + Q3 + (6 − Q4) + Q5
Purpose 합계     = Q6 + Q7 + Q8 + Q9 + Q10
Process 합계     = Q11 + Q12 + Q13 + Q14 + Q15

각 하위척도 평균 = 해당 합계 / 5
```

합계 범위는 각각 5–25, 평균 범위는 각각 1–5다. 세 요인을 구분해 검증한 척도이므로 이 리뷰에서는 세 값을 따로 해석한다. **전체 15문항을 하나로 합친 총점의 타당성이 검증되었다고 가정하지 않는다.** 합격 기준이나 결측 문항 처리 규칙은 여기서 임의로 만들지 않았다. 근거: [원문 Study 2 Materials, Table 4, Practical Implications](https://journals.sagepub.com/doi/10.1177/00187208231189000).

## 4. 논문의 이야기와 실험

저자는 사용자가 작동 과정이나 설계 용도에 대한 정보를 보지 못한다면 그 측면을 제대로 평가할 수도 없다고 지적한다. 이 때문에 목적·과정이 응답에서 분리되지 않았다고 해서 두 개념이 본래 동일하다고 단정할 수는 없다는 것이다. TOAST의 두 요인 결과를 이러한 관점에서 비판하지만, 이는 **STS 저자의 해석**이며 TOAST가 무효라는 직접 증거는 아니다.

### Study 1 — 익숙한 GPS를 평가

참가자가 가장 선호하는 GPS 앱을 평가하고, 약 7일 후 가장 덜 선호하는 GPS를 평가하게 했다. 첫 조사 444명, 후속 조사 354명이 분석 대상이다. 익숙한 앱을 대상으로 성능·용도·경로 선택 과정을 평가할 수 있을 것이라는 설계다. EFA를 통해 최종 세 요인을 구성하고 후속 자료에서 구조를 확인했다. 초기 후보 문항은 이 리뷰에 재수록하지 않는다. [원문 Study 1]

### Study 2 — 예측 모델의 성능·용도·과정을 다르게 제시

302명이 학생의 GPA를 추정하는 과제를 수행하며 통계 모델도 함께 평가했다. 연습 후(T1), 본 과제 후(T2)에 STS를 받았다.

| 조건 | 조작한 내용 | 해당 요인의 의미 |
| --- | --- | --- |
| Low-performance | 모델의 예측 정확도를 낮춤 | 작업을 잘 수행하지 못함 |
| Low-purpose | 한 유형의 대학 자료로 학습된 모델을 다른 유형의 대학에 적용한다고 설명 | 학습·설계 맥락과 사용 맥락의 불일치 |
| Low-process | 가중치와 계산 방법 정보를 제거 | 어떻게 예측했는지 알기 어려움 |
| Control | 위 측면을 저하시키지 않은 기준 조건 | 비교 기준 |

이 설계에서 **Purpose는 사용자 의도 추론**, **Process는 단순 응답 속도**를 뜻하지 않는다. Purpose는 현재 용도에 대한 적합성, Process는 계산 과정의 가시성에 가깝다. 이 차이가 본인 실험과 척도의 적합성을 판단하는 핵심이다. 근거: [원문 Study 2 Method](https://journals.sagepub.com/doi/10.1177/00187208231189000).

## 5. 문항별 요인적재량

**Table 4의 표준화 요인적재량**이다. 앞서 TOAST 리뷰에 수록한 비표준화 계수와 숫자의 크기를 직접 비교하면 안 된다. 문항끼리의 상관행렬이 아니라 각 문항이 소속 요인과 얼마나 연결되는지를 나타낸다. 모든 적재량은 원문에서 p < .01로 보고했다.

| 문항 | 요인 | 연습 후 T1 | 과제 후 T2 |
| --- | --- | --- | --- |
| Q1 | Performance | .86 | .93 |
| Q2 | Performance | .87 | .90 |
| Q3 | Performance | .86 | .91 |
| Q4 (R) | Performance | .61 | .77 |
| Q5 | Performance | .89 | .92 |
| Q6 | Purpose | .62 | .74 |
| Q7 | Purpose | .81 | .85 |
| Q8 | Purpose | .74 | .84 |
| Q9 | Purpose | .80 | .79 |
| Q10 | Purpose | .60 | .75 |
| Q11 | Process | .68 | .84 |
| Q12 | Process | .58 | .67 |
| Q13 | Process | .76 | .85 |
| Q14 | Process | .80 | .90 |
| Q15 | Process | .86 | .92 |

Q12의 설명 전달은 Process에 양의 적재량을 보이지만 같은 요인의 이해·명확성 문항보다 수치가 낮다. 설명이 있다는 평가와 이해가 명확하다는 평가가 완전히 같지는 않을 수 있다는 **리뷰 해석**이 가능하다. 이것만으로 Q12를 빼야 한다는 뜻은 아니다. 출처: [원문 Table 4](https://journals.sagepub.com/doi/10.1177/00187208231189000).

## 6. 신뢰도와 요인 간 상관

| 하위척도 | Study 1 α | Study 2 T1 α | Study 2 T2 α |
| --- | --- | --- | --- |
| Performance | .87 | .91 | .95 |
| Purpose | .80 | .84 | .90 |
| Process | .82 | .86 | .92 |

| 요인 간 상관 | Study 1 | Study 2 T1 | Study 2 T2 |
| --- | --- | --- | --- |
| Performance–Purpose | .67 | .70 | .73 |
| Performance–Process | .20 | .53 | .49 |
| Purpose–Process | .27 | .60 | .63 |

출처: [원문 Study 1 Results 및 Table 2](https://journals.sagepub.com/doi/10.1177/00187208231189000).α는 내적 일관성으로, 높다고 개념적 중복이나 타당도 문제가 모두 해결되는 것은 아니다.

**Performance와 Purpose의 높은 상관은 저자도 한계로 인정한다.** 잘 못하는 시스템을 보면 성능이 낮은 것인지 용도에 맞지 않는 것인지 사용자가 구별하기 어려울 수 있다. 세 요인 CFA가 더 잘 맞았지만, 세 점수가 완전히 독립적이라고 설명하면 안 된다.

Study 2의 3요인 모형 적합도는 T1에서 CFI = .95, RMSEA = .06, SRMR = .05, T2에서 CFI = .96, RMSEA = .07, SRMR = .04였다. [원문 Table 3]

과제 후 **의존 의도**와 상관은 Performance .66, Purpose .51, Process .38이었다. 성능 평가와 의존 의도의 연결이 가장 강했다. 그러나 실제 보너스 계산에 모델 또는 본인의 예측을 선택하는 **의존 행동**과의 관계는 훨씬 제한적이었으며, 저자도 관련 가설이 부분적으로만 지지되었다고 설명한다. 이 설문 점수를 실제 의존 행동의 직접 대체물로 해석하지 않는다. [원문 Table 2 및 Study 2 Results]

## 7. TOAST와 비교하면 무엇이 달라지는가

아래 비교는 두 원문의 문항에 근거한 리뷰 해석이다. TOAST의 근거와 문항은 [TOAST 리뷰](TOAST.md)에 정리되어 있다.

| 비교 기준 | TOAST | STS |
| --- | --- | --- |
| 구성 | Understanding 4 + Performance 5 | Performance 5 + Purpose 5 + Process 5 |
| 응답 | 7점, 역채점 없음 | 5점, Q4 역채점 |
| 이해 관련 | 역할·한계·능력·수행 방식에 대한 이해 | 작동·의사결정의 투명성과 이해 가능성에 집중 |
| 성능 관련 | 목표 달성, 일관성, 기대에 맞는 동작, 편안한 의존, 예측 가능성 | 효과성, 정확성, 신뢰성, 유능함, 전반적 수행 |
| 목적 관련 | 역할 등을 Understanding 안에서 다룸 | 설계 의도와 현재 사용 맥락의 적합성을 별도 평가 |
| 설명 제공을 직접 묻는가 | 독립적인 설명 전달 문항은 없음 | Q12가 reasoning 전달을 직접 물음 |
| 한계 인식을 직접 묻는가 | “I understand the limitations of the system.” | 최종 15문항에 같은 형태의 직접 문항은 없음 |

### 현재 척도 선택에 대한 해석

- **시스템을 얼마나 이해하고 편하게 의존하는지**를 짧게 보고 싶다면 TOAST 문항이 잘 맞을 수 있다.
- **설명·판단 근거 제공으로 과정의 투명성이 달라지는지**가 중심이라면 STS의 Process를 자세히 볼 만하다.
- **현재 작업·맥락에 적합한 시스템인지**를 연구한다면 STS Purpose가 관련된다. 단, 조건 간 설계 용도나 적용 맥락이 바뀌지 않으면 차이가 작을 수 있다.
- **사람의 의도를 시스템이 잘 이해했는지**가 핵심이라면 STS Purpose를 이름만 보고 선택하면 안 된다. 그 개념을 직접 묻지 않는다.

어느 쪽이 더 적합한지는 인용수나 최신 연도보다 **실험에서 바꾼 것과 설문이 묻는 것이 일치하는지**로 판단해야 한다. 하위척도만 쓰거나 “statistical model”을 로봇 이름 등으로 수정한다면 선택·변경 사실을 보고하고, 원래 전체 척도와 동일한 검증을 받았다고 가정하지 않는다.
